export type InformacaoUser={
    id:number
    nome:string
    email:string
}