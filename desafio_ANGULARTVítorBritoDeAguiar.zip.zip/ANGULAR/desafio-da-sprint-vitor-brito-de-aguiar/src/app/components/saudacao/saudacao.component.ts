import { Component } from '@angular/core';

@Component({
  selector: 'app-saudacao',
  imports: [],
  templateUrl: './saudacao.component.html',
  styleUrl: './saudacao.component.css'
})
export class SaudacaoComponent {

}
